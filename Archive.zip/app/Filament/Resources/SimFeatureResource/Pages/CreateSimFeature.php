<?php

namespace App\Filament\Resources\SimFeatureResource\Pages;

use App\Filament\Resources\SimFeatureResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSimFeature extends CreateRecord
{
    protected static string $resource = SimFeatureResource::class;
}
