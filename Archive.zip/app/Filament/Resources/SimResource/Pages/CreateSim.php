<?php

namespace App\Filament\Resources\SimResource\Pages;

use App\Filament\Resources\SimResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSim extends CreateRecord
{
    protected static string $resource = SimResource::class;
}
